CREATE TABLE review (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    rating INT,
    text VARCHAR(1000),
    FOREIGN KEY (book_id) REFERENCES book(id)
);