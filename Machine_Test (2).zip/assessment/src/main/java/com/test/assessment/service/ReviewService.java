package com.test.assessment.service;

import com.test.assessment.entity.Review;
import com.test.assessment.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ReviewService {
    @Autowired
    private ReviewRepository reviewRepository;

    public void postReview(Review review) {
        reviewRepository.save(review);
    }

    public Flux<Review> getAllReview(Review review) {
        return reviewRepository.findAll(review);
    }
    public Flux<Review> getReviewById(Long id) {
        return reviewRepository.findAll(id);
    }
    public Flux<Review> createReview(Review review) {
        return reviewRepository.save();
    }
    public Review updateReview(String id, Review review) {
        Review existingReview =reviewRepository.findById(String.valueOf(review.getId())).orElse(null);
        assert existingReview != null;
        existingReview.setRating(review.getRating());
        existingReview.setText(review.getText());
        return reviewRepository.save(existingReview);
    }
    public Flux<Void> deleteReview(Long id) {
        return reviewRepository.deleteById(id);
    }
}
