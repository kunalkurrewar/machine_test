package com.test.assessment.service;

import com.test.assessment.entity.Book;
import com.test.assessment.entity.Review;
import com.test.assessment.repository.BookRepository;
import com.test.assessment.repository.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;


import java.util.List;


@Service
public class BookService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private BookRepository bookRepository;

    public Flux<Book> getAllBooks(Book book) {
        return bookRepository.findAll(book);
    }
    public Flux<Book> getBookById(Long id) {
        return bookRepository.findAll(id);
    }
    public Flux<Book> createBook(Book book) {
        return bookRepository.save();
    }
    public Book updateBook(String id, Book book) {
        Book existingbook =bookRepository.findById(book.getId()).orElse(null);
        assert existingbook != null;
        existingbook.setTitle(book.getTitle());
        existingbook.setAuthor(book.getAuthor());
        existingbook.setPublication_year(book.getPublication_year());
        return bookRepository.save(existingbook);
    }
    public Flux<Void> deleteBook(String id) {
        return bookRepository.deleteById(id);
    }

    public double calculateAverageRatingOfBook(Book book) {
        List<Review> reviews = reviewRepository.findByBook(book);
        if (reviews.isEmpty()) {
            return 0.0;
        }

        double sum = reviews.stream().mapToInt(Review::getRating).sum();
        return sum / reviews.size();
    }
}

