package com.test.assessment.repository;

import com.test.assessment.entity.Book;
import com.test.assessment.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review,String> {
    List<Review> findByBook(Book book);

    Flux<Review> findAll(Review review);

    Flux<Review> findAll(Long id);

    Flux <Void> deleteById(Long id);

    Flux<Review> save();
}
